let app = require('express')();
let http = require('http').createServer(app);
let io = require('socket.io')(http);
const MongoClient = require('mongodb').MongoClient;
const connectionString = "mongodb+srv://nithya:TA44MttQgrGMrU0Q@cluster0.uqtl3.mongodb.net/rock_paper_scissor?retryWrites=true&w=majority";

io.on('connection', (socket) => {
    console.log('a user connected');
    socket.on('disconnect', () => {
        console.log('user disconnected');
    });
    socket.on('user played', (userInput) => {
        console.log('User input is: ' + JSON.stringify(userInput));
        MongoClient.connect(connectionString, {useUnifiedTopology: true}, (err, client) => {
            if (err) return console.error(err);
            console.log('Connected to Database');
            const dbo = client.db("rock_paper_scissor");
            const timeSort = { createdAt: -1 };
            dbo.collection("roundInfo").find().sort(timeSort).limit(1).toArray(function(err, lastRecord) {
                if(err) throw err;
                client.close();
                console.log("last rec is: ", lastRecord);
                if(lastRecord.playedWith === ""){
                    lastRecord.playedWith = userInput.userName;
                    userInput.playedWith = lastRecord.userName;
                    if(userInput.choice.toLowerCase() === lastRecord.choice.toLowerCase()){
                        lastRecord.result = 'Draw';
                        userInput.result = 'Draw';
                    }
                    switch(userInput.choice.toLowerCase(){
                        case 'p': if(lastRecord.choice.toLowerCase() === 's'){
                                    lastRecord.result = 'Won';
                                    userInput.result = 'Lost';
                                  }else {
                                    lastRecord.result = 'Lost';
                                    userInput.result = 'Won';
                                  }
                        case 's': if(lastRecord.choice.toLowerCase() === 'r'){
                                    lastRecord.result = 'Won';
                                    userInput.result = 'Lost';
                                  }else {
                                    lastRecord.result = 'Lost';
                                    userInput.result = 'Won';
                                  }
                        case 'r': if(lastRecord.choice.toLowerCase() === 'r'){
                                    lastRecord.result = 'Won';
                                    userInput.result = 'Lost';
                                   }else {
                                    lastRecord.result = 'Lost';
                                    userInput.result = 'Won';
                                   }
                    })
                }
            })
        })
    });

    socket.on('', (res)=> {
        console.log(res);
    })
});
http.listen(3000, () => {
    console.log('listening on *:3000');
});