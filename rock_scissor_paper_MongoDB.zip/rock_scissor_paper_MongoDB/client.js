const io = require("socket.io-client");
const readline = require('readline');
const rl = readline.createInterface({ input: process.stdin,  output: process.stdout });

rl.question('Whats your name? ', (name) => {
    let socket = io.connect("http://localhost:3000");

    socket.on('connect', () => {
        console.log('Successfully connected to server');
        rl.question('(R)ock, (P)aper or (S)cissors? ', (ans) => {
            console.log(`You chose ${ans}`);
            const  clientTimestamp = Date.now();
            console.log(`Waiting for response`);
            let user = {
                "choice" : `${ans}`,
                "playedWith": "",
                "response":false,
                "result" : "",
                "userName" : `${name}`,
                "createdAt" : `${clientTimestamp}`
            }
            socket.emit('user played', user);
        })
    });
  
    socket.on('disconnect', () => {
        console.log('Connection lost...');
        rl.prompt();
    });  
})