const lastRec = await roundInfoRef.orderBy('createdAt', 'desc')
.limit(1)
.get()
.then(docs => docs.forEach(doc => {
    if (doc.data().response == false) {
        roundInfoRef.doc(doc.id).update({
            response: true,
            playedWith: name
        })
        let result;
        if (doc.data().choice == ans) {
            doc.data().result = 'draw';  
        } else if (doc.data().choice == 'S') {
            if (ans == 'P') {
                //Previous user wins
                roundInfoRef.doc(doc.id).update({
                    result: 'won'
                })
                result = 'lost';
            } else {
                //current user wins
                roundInfoRef.doc(doc.id).update({
                    result: 'lost'
                })
                result = 'won';
            }
        } else if (doc.data().choice == 'P') {
            if (ans == 'S') {
                //current user wins
                roundInfoRef.doc(doc.id).update({
                    result: 'lost'
                })
                result = 'won';
            } else {
                //Previous user wins
                roundInfoRef.doc(doc.id).update({
                    result: 'won'
                })
                result = 'lost';
            }
        } else if (doc.data().choice == 'R') {
            if (ans == 'S') {
                //current user wins
                roundInfoRef.doc(doc.id).update({
                    result: 'lost'
                })
                result = 'won';
            } else {
                //Previous user wins
                roundInfoRef.doc(doc.id).update({
                    result: 'won'
                })
                result = 'lost';
            }
        }
        addCurrentUsertoDB(result);
    }
    function addCurrentUsertoDB(currentResult) {  
        roundInfoRef.add({
            choice: ans,
            playedWith: doc.data().userName,
            response: true,
            result: currentResult,
            userName: name,
            createdAt: serverTimestamp()
        });
    }

}))
.catch(exception => console.log(exception));

    // rl.on('line', (message) => {
    //     console.log(`Sending message: ${message}`);
    //     socket.emit('chat message', `${userInput} says ${message}`);
    //     rl.prompt();
    // });

    //socket.broadcast.emit('chat message', msg);